import { expect, test } from "../fixtures/fixture";
import * as dotenv from "dotenv";
import LoginPage from "./pages/loginPage/loginPage";
import ProductPage from "./pages/productPage/productPage";
import CartPage from "./pages/cartPage/cartPage";

let page: any;
let loginPage: LoginPage;
let productPage: ProductPage;
let cartPage: CartPage;

dotenv.config({ path: "./.env" });

const baseUrl = process.env.BASE_URL;
if (!baseUrl) {
  throw new Error("Base_URL is missing or empty");
}
const userName = process.env.LOGIN_USERNAME;
const password = process.env.LOGIN_PASSWORD;
if (!userName || !password) {
  throw new Error("Login environment variables are missing or empty");
}

test.describe("Shopping Cart Suite", { tag: "@cart" }, () => {
  test.beforeEach("open start url", async ({ browser }) => {
    page = await browser.newPage();
    loginPage = new LoginPage(page);
    productPage = new ProductPage(page);
    cartPage = new CartPage(page);
    await page.goto(baseUrl);
  });

  test.afterEach(async () => {
    await page.close();
  });

  test("E2E", async () => {
    await loginPage.login(userName, password);
    await loginPage.clickOnLoginButton();
    await expect(page.getByText("Products", { exact: true })).toBeVisible();
    await productPage.clickOnAddToCart();
    await productPage.clickOnShoppingCartButton();
    await expect(
      page.getByText("Sauce Labs Backpack", { exact: true }),
    ).toBeVisible();
  });

  test("user can remove a product from the cart", async () => {
    await loginPage.login(userName, password);
    await loginPage.clickOnLoginButton();
    await expect(page.getByText("Products", { exact: true })).toBeVisible();
    await productPage.clickOnAddToCart();
    await productPage.clickOnShoppingCartButton();
    await expect(
      page.getByText("Sauce Labs Backpack", { exact: true }),
    ).toBeVisible();
    await cartPage.clickOnRemoveButton();
    await expect(
      page.getByText("Sauce Labs Backpack", { exact: true }),
    ).toHaveCount(0);
  });
});

test("outside the suite @sanity", async () => {
  console.log("outside the suite sanity");
});
